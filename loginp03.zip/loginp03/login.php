<?php
  $servername = "localhost";//nommbre del servidor de la BD.
  $dbusername = "root";//nombre del usuario para conectar a la BD.
  $dbpassword = ""; //definimos la contraseña para conectar a la BD.
  $dbname = "practica"; //colocamos el nombre de nuestra bd de mysql.

//crear conexion.
// $conn = new mysqli($host,$user,$pass,$db);
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

//verificar conexion 
if($conn->connect_error){
    die("conexion fallida: " . $conn->connect_error);
}
//recoger los datos del formulario ya estando registrados en la BD 
$userName = $_POST['username']; // campo de nombre de usuario con el que se registro.
$userPw = $_POST['password'];//campo de contraseña

//crear la consulta SQL 
$sql = "SELECT * FROM usuario WHERE userName = '$userName' AND userPw = '$userPw'";
//seleccionamos la tabla y sus dos campos principales.

//ejecuta la consulta 
$result = $conn->query($sql);

//verifica si el usuario existe 
if($result->num_rows > 0){
include ('views/exito.html'); //en caso de que exista el usuario nos dirigira a una ventana,
//donde aparecera un mensaje de "usuario valido".
//echo "has ingresado con exito"

}else{
    include('views/errorLogin.html');//si ingresa mal el usuario o la contraseña nos mandara a una,
    //segunda pagina donde aparecera un mensaje que dira error.
    //echo "error"
}
$conn->close(); //cerramos consulta.
?>