<!DOCTYPE html> <!--indicamos que utilizaremos html5-->
<html lang="en"><!--esta establecido el lenguaje-->
  <head><!--etiqueta de apertira para la pestaña-->
    <meta charset="utf-8" /><!--atributo que hace respetar la escritura-->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
     integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x"
      crossorigin="anonymous"><!--indicamos que utilizaremos Bootstrap-->
    <title>REGISTRO</title><!--titulo que se le asigna a la pestaña-->
    <link rel="stylesheet" href="../css/vregister.css"><!--mandamos a traer la hoja de estilos-->
    </head> <!--cierre del encabezado-->
<body><!---abrimos etiqueta de contenido-->
<form method="post" action="register.php"> <!--creamos un formulario con accion de registrar en la BD-->
        <label for="username">USUARIO:</label><!--asignamos el primer texto de usuario-->
        <input type="text" id="username" name="username" required/> <!--casilla que de tipo texto-->
        <label for="password">CONTRASEÑA:</label><br><!--segundo texto de registro-->
        <input type="password" id="password" name="password" required/><!--casilla tipo password-->
        <label for="userFechaAlta">FECHA:</label><br><!--tercer texto del formulario-->
        <input type="date" id="date" name="userFechaAlta" required/><!--casilla tipo date-->
        <label for="userDireccion">CORREO ELECTRONICO:</label><br><!--cuarto texto-->
        <input type="email" id="userDireccion" name="userDireccion" required/><!--casilla tipo email-->
        <label for="Telefono">TELEFONO:</label><br><!--quinto texto del formulario-->
        <input type="number" id="Telefono" name="Telefono" required/><!--casilla tipo number-->
        <input type="submit" value="registrar" /><!--boton que envia los datos ingresados a la bd pasando 
        por el proceso de incertado de register.php-->
    </form><!--cierre de formulario-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" 
    crossorigin="anonymous"></script><!--incluimos la biblioteca JavaScript de Bootstrap-->
  </body><!--cierre del contenido de la pagina-->
  </html><!--cierrre del cuerpo HTML-->

