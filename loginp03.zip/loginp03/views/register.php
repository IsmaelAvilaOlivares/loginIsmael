<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //estos son los name del los campos del formulario.
    $userName = $_POST["username"]; // Cambiado a "username"
    $password = $_POST["password"]; // Cambiado a "password"
    $userFechaAlta = $_POST["userFechaAlta"];//le asignamos la fecha a la variable con $
    $userDireccion = $_POST["userDireccion"];//le asignamos la direccion a la variable con $
    $Telefono = $_POST["Telefono"];//le asignamos el telefono a la varible con $

    $servername = "localhost";//nommbre del servidor de la BD.
    $dbusername = "root";//nombre del usuario para conectar a la BD.
    $dbpassword = ""; //definimos la contraseña para conectar a la BD.
    $dbname = "practica"; //colocamos el nombre de nuestra bd de mysql.  

    // Crea la conexión
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    // Verifica la conexión 
    if ($conn->connect_errno) {
        die("Connection failed: " . $conn->connect_errno);//en caso de que no se conectar a la BD,
        //arrojara un conexion fallida.
    }

    // Prepara la sentencia SQL
    $stmt = $conn->prepare("INSERT INTO usuario (userName, userPw, userFechaAlta, userDireccion, Telefono) VALUES (?, ?, ?, ?, ?)");
    //indicamos que prepare el incertado de datos a la tabla, colocando los campos de nuestra tabla en el orden indicado y evaluando 
    //los campos vacios con un signo de "?" que seran los que se llenaran.
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);//mensaje de error
    }
    $stmt->bind_param("sssss", $userName, $password, $userFechaAlta, $userDireccion, $Telefono);//validamos los campos del formulario

    // Ejecuta la sentencia SQL 
    if ($stmt->execute()) {
            //verifica la sentencia y toma una decicion
        echo "Usuario registrado con éxito";//cuando se termine de registrar el usuario mostrara un mensaje.
    } else {
        echo "Error executing statement: " . $stmt->error;//en caso de que no cumpla con lo requerido mostrara un mensaje erroneo.
    }

    // Cierra la sentencia y la conexión
    $stmt->close();
    $conn->close();
}
?>