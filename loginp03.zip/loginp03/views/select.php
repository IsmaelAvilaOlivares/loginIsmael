<?php
$servername = "localhost"; //nommbre del servidor de la BD.
$dbusername = "root"; //nombre del usuario para conectar a la BD.
$dbpassword = ""; //definimos la contraseña para conectar a la BD.
$dbname = "practica"; //colocamos el nombre de nuestra bd de mysql.

// Crea la conexión
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

//verifica la conexion 
if ($conn->connect_errno) {
    die("error de conexion: " . $conn->connect_errno);//en caso de una conexion erronea muestra nmensaje.
}
//consulta para obtener los datos de la tabla "Usuario"
// $sql = "SELECT ID, userName, userPw FROM usuario";
$result = $conn->query("SELECT ID, userName, userPw FROM usuario");//seleccionamos 3 campos que visualizaremos su contenido.
if ($result->num_rows > 0) {
    echo "<table>";//mostrar una tabla 
    echo "<tr><th>ID</th><th>Nombre</th><th>Contraseña</th></tr>";//titulo de las columnas que se mostraran.
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["ID"] . "</td><td>" . $row["userName"] . "</td><td>" . $row["userPw"] . "</td></tr>";
    }//colocamos los nombre de los atributos de la tabla tal y como se escribieron en la creacion de la tu tabla
    echo "</table>"; //cerramos la etiqueta de la tabla 
} else {
    echo "no se encontraron registros."; //en caso de que no existan registros mostrara un mensaje.
}
$conn->close(); // Cierra la sentencia y la conexión
?>