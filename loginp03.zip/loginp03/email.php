<?php
// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP; // Agregamos la clase SMTP

// Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    // Configuración del servidor
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'avilaolivaresismael@gmail.com'; // Tu correo de Gmail
    $mail->Password   = 'upcr zlvc vkta mgup'; // Tu contraseña de Gmail o contraseña de aplicación
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Destinatarios
    $mail->setFrom('avilaolivaresismael@gmail.com', 'Mailer');
    $mail->addAddress('ismaelolivares135@gmail.com'); // Añade un destinatario

    // Contenido del correo
    $mail->isHTML(true);
    $mail->Subject = 'Asunto del correo';
    $mail->Body    = 'Este es el cuerpo del mensaje en HTML <b>en negritas</b>';
    $mail->AltBody = 'Este es el cuerpo del mensaje en texto plano para clientes que no admiten HTML';

    // Habilitar registro de depuración
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;

    $mail->send();
    echo 'El mensaje ha sido enviado';
} catch (Exception $e) {
    echo "No se pudo enviar el mensaje. Error de Mailer: {$mail->ErrorInfo}";
}